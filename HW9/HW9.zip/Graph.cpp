#include "Graph.hpp"
#include <vector>
#include <queue>
#include <iostream>

using namespace std;

void Graph::createEdge(string v1, string v2, int num){
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name==v1){
            for(int j = 0; j < vertices.size(); j++){
                if(vertices[j]->name==v2 && i != j){
                    adjVertex adjacentV;
                    adjacentV.v = vertices[j];
                    adjacentV.weight = num;
                    vertices[i]->adj.push_back(adjacentV);

                    adjVertex adjacentV2;
                    adjacentV2.v = vertices[i];
                    adjacentV2.weight = num;
                    vertices[j]->adj.push_back(adjacentV2);
                }
            }
        }
    }
}

void Graph::insertVertex(string n){
    bool flag = false;

    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name==n){
            flag= true;
        }
    }
    if(flag == false){
        vertex *v = new vertex;
        v->name = n;
        v->distance = 0;
        vertices.push_back(v);
    }
}

void Graph::displayEdges(){
    //loop through all vertices and adjacent vertices
    // cout<<"here"<<vertices.size()<<endl;
    for(unsigned int i = 0; i < vertices.size(); i++){
        cout<<vertices[i]->name<<":"<<endl;
        for(unsigned int j = 0; j < vertices[i]->adj.size(); j++){
            cout<<" --> "<< vertices[i]->adj[j].v->name << " "<<vertices[i]->adj[j].weight<<endl;
        }
        cout<<endl;
    }
}



void Graph::traverseWithDijkstra(string start){

}

void Graph::depthFirstTraversal(string sourceVertex)
{


}

void Graph::minDistPath(string source, string destination) {

}
